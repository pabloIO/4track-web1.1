'use strict';

/**
 * @ngdoc overview
 * @name 4trackApp
 * @description
 * # 4trackApp
 *
 * Main module of the application.
 */
angular
  .module('4trackApp', [
  	'uiGmapgoogle-maps',
    'ngFileUpload',
    'ngAnimate',
    'LocalStorageModule',
    'ngSanitize',
    'ngTouch',
    'ui.router',
    'chart.js',
    'btford.socket-io',
  ])
  .config(function(uiGmapGoogleMapApiProvider) {
    uiGmapGoogleMapApiProvider.configure({
        key: 'AIzaSyDAt346zZoKFEQl_cSDfXRvtj46Y5xr-_s',
        v: '3.20', //defaults to latest 3.X anyhow
        libraries: 'weather,geometry,visualization'
       });
  })
  .config(function($stateProvider, $urlRouterProvider, $locationProvider){
  	$stateProvider
      /*
      --------- Public states
      */
  		.state('inicio', {
  			url: '/',
  			views: {
  				'home-header': {
  					templateUrl: '/app/views/public/header.html'
  				},
  				'home-content': {
  					templateUrl: '/app/views/public/home.html',
            controller: 'LoginCtrl as vm'
  				},
          'home-footer': {
            templateUrl: '/app/views/public/footer.html'
          },
  			},
  		})
      /*
      ---------- Station states (AUTH)
       */
      .state('estacion',{
        url: '/inicio',
        views: {
          'station-header': {
            templateUrl: '/app/views/police/header.html',
            controller: 'HeaderStation as vm'
          },
          'station-content': {
            templateUrl: '/app/views/police/dashboard.html',
            controller: 'DashBoardCtrl as vm'
          },
          'station-footer': {
            templateUrl: '/app/views/police/footer.html'
          }
        }
      })
      .state('estacion.nuevo-policia', {
        url: '/crear-policia',
        views: {
          'station-content@': {
            templateUrl: '/app/views/police/police.html',
            controller: 'PoliceCtrl as vm'
          } 
        }
      })
      .state('estacion.policias', {
        url: '/policias',
        views: {
          'station-content@': {
            templateUrl: '/app/views/police/police-list.html',
            controller: 'PoliceListCtrl as vm'
          } 
        }
      })
      .state('estacion.track-device', {
        url: '/tracking-room/:idDisp',
        views: {
          'station-content@': {
            templateUrl: '/app/views/police/tracking-room.html',
            controller: 'PoliceMapRoom as vm'
          } 
        }
      })
  		.state('tracking', {
  			url: '/tracking',
  			views: {
  				'police-tracking': {
  					templateUrl: '/app/views/police/tracking.html',
  					controller: 'PoliceMap as vm'
  				} 
  			}
  		})
      /*
      .state('tracking-room', {
        url: '/tracking-room/:idUser/:idDevice',
        views: {
          'room-tracking': {
            templateUrl: '/app/views/police/tracking-room.html',
            controller: 'PoliceMapRoom as vm'
          } 
        }
      });
  		/*
  		.state('police', {
  			url: '/police',
  			views: {
  				'police-content': 
  			}
  		}); 
		  */
  		$urlRouterProvider.otherwise('/');
	  	$locationProvider.html5Mode(true);
  })
  .config(['localStorageServiceProvider', function(localStorageServiceProvider){
        localStorageServiceProvider.setPrefix('4trackApp');
  }])
  .run(function($transitions) {
      $transitions.onStart({ to: 'estacion.**' }, function(trans) {
        var auth = trans.injector().get('Auth');
        if (!auth.isAuth()) {
          // User isn't authenticated. Redirect to a new Target State
          return trans.router.stateService.target('inicio');
        }
      });
  });
  /*
  .run(['$rootScope', '$state', '$stateParams', 'Auth', 
        function($rootScope, $state, $stateParams, Auth){   
        $rootScope.$on('$stateChangeStart', function(evt, toState, toParams, fromState, fromParams) {
          console.log("$stateChangeStart " + fromState.name + JSON.stringify(fromParams) + " -> " + toState.name + JSON.stringify(toParams));
        });
        $rootScope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){
          event.preventDefault();
          console.log('Heeey');
          console.log(toState.name);
          console.log(Auth.isAuth());
          // Enviar a sesion automaticante si el usuario esta autentificado 
          if(!Auth.isAuth()){
            $state.go(toState.name);
          }else{
            $state.go('inicio');
          }
          if(toState.name == 'inicio'){
            $state.go(toState.name);
          }else if(toState.name == 'desarrolladores'){
            $state.go(toState.name);
          }else if(toState.name == 'contacto'){
            $state.go(toState.name);
          }
        });
  }]);*/
