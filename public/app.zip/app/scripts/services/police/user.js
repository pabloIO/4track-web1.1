(function(){
	'use strict';
	angular.module('4trackApp')
		.factory('User', User)
		.constant('publicUrl','http://localhost:8080/api/v1');
	User.$inyect = ['$http', 'publicUrl'];
	function User($http, publicUrl){
		return{
			getStation: function(id){
				var promise = $http({
					method: 'GET',
					url: publicUrl + '/estacion/' + id,
				}).then(function(response){
					return response.data;
				});
				return promise;
			},
			newPoliceMan: function(data){
				var promise = $http({
					method: 'POST',
					url: publicUrl + '/policia',
					data: data
				}).then(function(response){
					return response.data;
				});
				return promise;
			},
			getPolicias: function(){
				var promise = $http({
					method: 'GET',
					url: publicUrl + '/policias',
				}).then(function(response){
					return response.data;
				});
				return promise;
			},
		};
	};
})();