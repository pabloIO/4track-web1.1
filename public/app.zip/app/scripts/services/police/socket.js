(function(){
	'use strict';
	angular.module('4trackApp')
		.factory('Socket', Socket);
	Socket.$inyect = ['$rootScope'];
	function Socket(socketFactory, $rootScope){
		var nsps = ['/device-tracking'];
		return {
			defaultSocket: socketFactory({
				ioSocket: io.connect()
			}),
			trackRoom: socketFactory({
				ioSocket: io.connect(nsps[0])
			})
		};
	};
})();