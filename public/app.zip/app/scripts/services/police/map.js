(function(){
	'use strict';
	angular.module('4trackApp')
		.factory('Map', Map)
		.constant('publicUrl', 'http://localhost:8080/api/v1');
	Map.$inyect = ['$http', 'publicUrl'];
	function Map($http, publicUrl){
		return {
			subirCoords: function(data){
				var promise = $http({
					method: 'POST',
					url: publicUrl + '/track-map',
					data: data
				}).then(function(response){
					return response.data;
				});
				return promise;
			},
			syncDevicePolice: function(data){
				var promise = $http({
					method: 'POST',
					url: publicUrl + '/dispositivo/police/sync',
					data: data
				}).then(function(response){
					return response.data;
				});
				return promise;
			},
			sendToPolice: function(data){
				var promise = $http({
					method: 'POST',
					url: publicUrl + '/dispositivo/police/send',
					data: data
				}).then(function(response){
					return response.data;
				});
				return promise;
			},
		};
	};
})();