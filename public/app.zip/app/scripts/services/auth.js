(function(){
	'use strict';
	angular.module('4trackApp')
		.factory('Auth', Auth)
		.constant('publicUrl', 'http://localhost:8080/api/v1');
	Auth.$inyect = ['$http', '$state', 'publicUrl', 'localStorageService'];
	function Auth($http, $state, publicUrl, localStorageService){
		var storage = localStorageService;
		return {
			setUid: function(uid){
				return storage.cookie.set('uid', uid, 7);
			},
			getUid: function(){
				return storage.cookie.get('uid');
			},
			isAuth: function(){
				return storage.cookie.get('uid') != null;
			},
			setLatitude: function(lat){
				return storage.cookie.set('lat', lat, 7);
			},
			getLatitude: function(){
				return storage.cookie.get('lat');
			},
			setLongitude: function(lon){
				return storage.cookie.set('lng', lon, 7);
			},
			getLongitude: function(){
				return storage.cookie.get('lng');
			},
			setCoords: function(lat, lon){
				this.setLatitude(lat);
				this.setLongitude(lon);
			},
			getCoords: function(){
				return {
					latitude: this.getLatitude(),
					longitude: this.getLongitude()
				};
			},
			setSession: function(uid, coords){
				this.setUid(uid);
				this.setCoords(coords.latitude, coords.longitude);
			},
			login: function(data){
				var promise = $http({
					method: 'POST',
					url: publicUrl + '/login-estacion',
					data: data
				}).then(function(response){
					return response.data;
				});
				return promise;
			},
			logOut: function(){
				storage.cookie.clearAll();
				$state.go('inicio');
			}
		};
	};
})();