(function(){
	'use strict';
	angular.module('4trackApp')
		.controller('HeaderStation', HeaderStation);
	HeaderStation.$inyect = ['Auth'];
	function HeaderStation(Auth){
		var vm = this;
		vm.cerrarSesion = cerrarSesion;

		function cerrarSesion(){
			Auth.logOut();
		};
	};
})();