(function(){
	'use strict';
	angular.module('4trackApp')
		.controller('PoliceListCtrl', PoliceListCtrl);
	PoliceListCtrl.$inyect = ['Auth', 'User'];
	function PoliceListCtrl(Auth, User){
		var vm = this;
		vm.getPolicias = getPolicias;
		vm.policias = [];
		function getPolicias(){
			User.getPolicias().then(function(data){
				if(data.success){
					vm.policias = data.policias;
				}else{
					Materialize.toast(data.msg, 4000);
				}
			}, function(err){
				Materialize.toast('Hubo un error en el servidor', 4000);
			});
		};


		getPolicias();
	};
})();