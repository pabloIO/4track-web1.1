(function(){
	'use strict';
	angular.module('4trackApp')
		.controller('DashBoardCtrl', DashBoardCtrl);
	DashBoardCtrl.$inyect = ['Socket', 'User', 'Auth', '$scope', '$timeout', '$state', 'uiGmapGoogleMapApi'];
	function DashBoardCtrl(Socket, User, Auth, $scope, $timeout, $state, uiGmapGoogleMapApi){
		var vm = this;
		vm.map = {
			center: {},
			zoom: 17,
		};
		vm.marker = {
            id: Date.now(),
            coords: {
				latitude: parseFloat(Auth.getLatitude()),
				longitude: parseFloat(Auth.getLongitude())
			},
        };
        vm.anyAlert = anyAlert;
		vm.getUserData = getUserData;
		vm.userData = {};
		vm.isShowed = false;
		vm.onCount = 0;
		vm.initInterval = initInterval;
		vm.cancelInterval = cancelInterval;
		vm.startInterval = startInterval;
		vm.alerts = [];
		vm.isFirstEmit = {
			initMarker: true,
			state: false,
		};
		vm.alertRoom = {
			idUser: '',
			idDevice: ''
		};
		vm.fireAlert = fireAlert;
		vm.isEmitting = true;
		var promise;
		console.log(Auth.getCoords());
		
        // Sockets
        //Socket.defaultSocket.on('start:tracking', function(state){
        //	vm.isEmitting = state.isActive;
        //});
        Socket.defaultSocket.on('station-room', function(coords){
        	console.log(coords);
        	var alert = JSON.parse(coords);
        	vm.alertRoom.idUser = coords.idUser;
        	vm.alertRoom.idDevice = coords.idDevice;
        	sortAlerts(alert);
        });
        // Recibir datos en tiempo real, para activar una notificacion
        Socket.defaultSocket.on('device-signal', function(coords){
        	var alert = JSON.parse(coords);
        	vm.alertRoom.idUser = coords.idUser;
        	vm.alertRoom.idDevice = coords.idDevice;
        	sortAlerts(alert);
			console.log(vm.routeGraph);
			/*
			vm.isFirstEmit.state = coords.isFirstEmit.state;
			if(vm.isFirstEmit.initMarker){
				vm.markers[0].coords = {
					latitude: coords.latitude,
					longitude: coords.longitude
				};
				//vm.isFirstEmit.initMarker = false;
				Socket.defaultSocket.emit('initMarker', {active: false});
				console.log('primer marker');
			}
			vm.markers[1].coords = {
				latitude: coords.latitude,
				longitude: coords.longitude
			};
			*/
        });
		Socket.defaultSocket.on('tracking', function(coords){
			vm.routeGraph.path.push({
				latitude: coords.latitude,
				longitude: coords.longitude
			});
			console.log(vm.routeGraph);
			vm.isFirstEmit.state = coords.isFirstEmit.state;
			if(vm.isFirstEmit.initMarker){
				vm.markers[0].coords = {
					latitude: coords.latitude,
					longitude: coords.longitude
				};
				//vm.isFirstEmit.initMarker = false;
				Socket.defaultSocket.emit('initMarker', {active: false});
				console.log('primer marker');
			}
			vm.markers[1].coords = {
				latitude: coords.latitude,
				longitude: coords.longitude
			};
		});

		function anyAlert(){
			return vm.alerts.length == 0;
		};
		function getUserData(){
			User.getStation(Auth.getUid()).then(function(data){
				if(data.success){
					vm.userData = data.estacion;
					vm.map.center = {
						latitude: data.estacion.coords.latitude,
						longitude: data.estacion.coords.longitude,
					};
					vm.marker.coords = {
						latitude: data.estacion.coords.latitude,
						longitude: data.estacion.coords.longitude,
					};
					vm.isShowed = true;
				}else{
					$state.go('inicio');
				}
			}, function(err){
				console.error(err);
			});
		};
		function sortAlerts(data){
			console.log(vm.alerts.length, data);
			if(vm.alerts.length == 0){
				vm.alerts.push(data);
				return;				
			}
			for (var i = 0; i < vm.alerts.length; i++) {
				console.log(vm.alerts[i]);
				if(vm.alerts[i].idDevice == data.idDevice)
					return;
				else
					vm.alerts.push(data);
			}
			console.log(vm.alerts);
		};
		function fireAlert(){
			$('#alertaAuxilio').modal('hide');
			$timeout(function(){
				$state.go('tracking-room', vm.alertRoom);
			}, 500);
		};
		/*
		------- Funciones autoejecutables
		*/
		getUserData();
	};
})();