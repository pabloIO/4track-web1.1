(function(){
	'use strict';
	angular.module('4trackApp')
		.controller('PoliceMapRoom', PoliceMapRoom);
	PoliceMapRoom.$inyect = ['$state', '$stateParams', '$scope', '$timeout', 'Socket', 'Map', 'User', 'uiGmapGoogleMapApi'];
	function PoliceMapRoom($state, $stateParams, $scope, $timeout, Socket, Map, User, uiGmapGoogleMapApi){
		var vm  = this;
		vm.getCoords = getCoords;
		vm.enterRoom = enterRoom;
		vm.getPolicias = getPolicias;
		vm.enviarNotificacion = enviarNotificacion;
		vm.policias = [];
		vm.policeToSend = {
			idPolice: null
		};
		vm.mapRoom = {
			center: {},
			zoom: 16,
			refresh: false,
		};
		vm.isFirstEmit = {
			initMarker: true,
			state: false,
		};
		vm.isAsync = {
			state: false,
			msg: '',
			queueCoords: [],
			hasDequeue: false 
		};
		vm.firstNode = {
			latitude: null,
			longitude: null
		};
		vm.roomId = {
			idDevice: $stateParams.idDisp,
		};
		vm.socket = Socket.defaultSocket;
		
		vm.coords = {
			latitude: vm.mapRoom.center.latitude,
			longitude: vm.mapRoom.center.longitude
		};
		vm.markers = [
			{
				id: Date.now(),
				coords: {},
				options: {
					labelClass: 'marker_labels',
					labelAnchor: '12 60',
					labelContent: 'Punto de inicio'
				}
			},
			{
				id: Date.now(),
				coords: vm.coords,
				options: {
					labelClass: 'marker_labels',
					labelAnchor: '12 60',
					labelContent: 'Ubicación actual'
				}
			}
		];
		vm.marker = {
            id: Date.now(),
            coords: vm.coords,
        };
    	vm.routeGraph = {
        	id: Date.now(),
        	path: [],
        	fill: {
        		color: '#6495ed',
        		opacity: 0.6
        	},
        	stroke: {
        		color: '#1b61e4',
        		weight: 2
        	},
        	geodesic: true,
        	visible: true,
        };
        /*
        ----- Eventos del socket
         */
		// Escuchando por nuevas señales del auxilio
		vm.socket.on('alert-signal', function(coords){
			console.log(coords);
			var coordsParsed = JSON.parse(coords);
			vm.routeGraph.path.push({
				latitude:  coordsParsed.latitude,
				longitude: coordsParsed.longitude
			});
			vm.markers[1].coords = {
				latitude: coordsParsed.latitude,
				longitude: coordsParsed.longitude,
			};
			vm.mapRoom.center = {
				latitude: coordsParsed.latitude,
				longitude: coordsParsed.longitude,
			};
			vm.mapRoom.zoom = 16;
			vm.mapRoom.refresh = true;
			if(vm.policeToSend.idPoli){
				Map.sendToPolice({
					idPoli: vm.policeToSend.idPolice, 
					idDevice: vm.roomId.idDevice
				}).then(function(data){

				}, function(err){

				});
			}
		});
		/*
		------ Funciones
		 */
		function enviarNotificacion(idPoli, idDevice){
			vm.socket.emit('police-room', {idPoli: idPoli, idDevice: idDevice});
		};
		function getPolicias(){
			User.getPolicias().then(function(data){
				if(data.success){
					vm.policias = data.policias;
				}else{
					Materialize.toast(data.msg, 4000);
				}
			}, function(err){
				Materialize.toast('Hubo un error en el servidor', 4000);
			});
		};
		function enterRoom(){	
			vm.socket.emit('start-alert', vm.roomId);
		};
		function getCoords(){
			Map.syncDevicePolice({idDisp: vm.roomId.idDevice}).then(function(data){
				if(data.success){
					for (var i = 0; i < data.coords.coords.length; i++) {
						vm.routeGraph.path.push({
							latitude: data.coords.coords[i].latitude,
							longitude: data.coords.coords[i].longitude
						});
					};
					console.log(vm.routeGraph.path);
					vm.mapRoom.center = {
						latitude: vm.routeGraph.path[vm.routeGraph.path.length - 1].latitude,
						longitude: vm.routeGraph.path[vm.routeGraph.path.length - 1].longitude,
					};	
					vm.markers[0].coords = {
						latitude: vm.routeGraph.path[0].latitude,
						longitude: vm.routeGraph.path[0].longitude,
					};
					vm.markers[1].coords = {
						latitude: vm.routeGraph.path[vm.routeGraph.path.length - 1].latitude,
						longitude: vm.routeGraph.path[vm.routeGraph.path.length - 1].longitude,
					};	
					console.log(vm.markers);
					vm.mapRoom.refresh = true;
					vm.isAsync.state = true;
				}else{
					vm.isAsync.msg = data.msg;
				}
			}, function(err){
				console.error('Hubo un error en el servidor');
			});
		};
		/*
		----- Ejecucion automatica
		 */
		getPolicias();
		getCoords();
		enterRoom();

	};
})();