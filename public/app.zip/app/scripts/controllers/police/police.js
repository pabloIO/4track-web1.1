(function(){
	'use strict';
	angular.module('4trackApp')
		.controller('PoliceCtrl', PoliceCtrl);
	PoliceCtrl.$inyect = ['Auth', 'User'];
	function PoliceCtrl(Auth, User){
		var vm = this;
		vm.codigos_area = [
			{label: '+591'}, 
		];
		vm.registrarPolicia = registrarPolicia;
		vm.nuevoPolicia = {
			nombre: '',
			apellidos: {
				apat: '',
				amat: ''
			},
			codigo: '',
			password: '',
			telefono: {
				celular: 0,
				codigo_area: '+591'
			},
			isUploaded: {
				state: false,
				msg: ''
			}
		};
		function registrarPolicia(){
			var formData = {
				nombre: vm.nuevoPolicia.nombre,
				apellidos: vm.nuevoPolicia.apellidos,
				codigo: vm.nuevoPolicia.codigo,
				password: vm.nuevoPolicia.password,
				telefono: vm.nuevoPolicia.telefono,
			};
			console.log(formData);
			User.newPoliceMan(formData).then(function(data){
				if(data.success){
					Materialize.toast(data.msg, 4000) // 4000 is the duration of the toast
					vm.nuevoPolicia = {
						nombre: '',
						apellidos: {
							apat: '',
							amat: ''
						},
						codigo: '',
						password: '',
						telefono: {
							celular: 0,
							codigo_area: '+591'
						},
						isUploaded: {
							state: false,
							msg: ''
						}
					};
				}else{
					Materialize.toast(data.msg, 4000);
				}
			}, function(err){
				console.error('Hubo un error en el servidor');
			});
		};

	};
})();