(function(){
	'use strict';
	angular.module('4trackApp')
		.controller('PoliceMap', PoliceMap);
	PoliceMap.$inyect = ['Socket', '$scope', '$timeout', '$interval', '$state', 'uiGmapGoogleMapApi'];
	function PoliceMap(Socket, $scope, $timeout, $interval, $state, uiGmapGoogleMapApi){
		var vm = this;
		vm.onCount = 0;
		vm.initInterval = initInterval;
		vm.cancelInterval = cancelInterval;
		vm.startInterval = startInterval;
		vm.alerts = [];
		vm.isFirstEmit = {
			initMarker: true,
			state: false,
		};
		vm.alertRoom = {
			idUser: '',
			idDevice: ''
		};
		vm.fireAlert = fireAlert;
		vm.isEmitting = true;
		var promise;
		vm.map = {
			center: {
				latitude: -16.5,
				longitude: -68.13
			},
			zoom: 14,
		};
		vm.coords = {
			latitude: vm.map.center.latitude,
			longitude: vm.map.center.longitude
		};
		vm.markers = [
			{
				id: Date.now(),
				coords: {},
				options: {
					labelClass: 'marker_labels',
					labelAnchor: '12 60',
					labelContent: 'Punto de inicio'
				}
			},
			{
				id: Date.now(),
				coords: vm.coords,
				options: {
					labelClass: 'marker_labels',
					labelAnchor: '12 60',
					labelContent: 'Ubicación actual'
				}
			}
		];
		vm.marker = {
            id: Date.now(),
            coords: vm.coords,
            /*events: {
		        dragend: function (marker, eventName, args) {
		          var lat = marker.getPosition().lat();
		          var lon = marker.getPosition().lng();
		          vm.marker.coords= {
		          	latitude: lat,
		          	longitude: lon
		          };
		        }
		    }*/
        };
        uiGmapGoogleMapApi.then(function(){
        	vm.routeGraph = {
	        	id: Date.now(),
	        	path: [],
	        	fill: {
	        		color: '#6495ed',
	        		opacity: 0.6
	        	},
	        	stroke: {
	        		color: '#1b61e4',
	        		weight: 2
	        	},
	        	geodesic: true,
	        	visible: true,
	        	icons: [{
	        		icon: {
	        			path: google.maps.SymbolPath.CIRCLE
	        		},
	        		offset: '25px',
	                repeat: '50px'
	        	}]
	        };
        });
        // Ver el estado de cambio de las coordenadas
        $scope.$watch('vm.coords', function(newVal, oldVal){
        	vm.marker.coords = newVal;
        });
        // Sockets
        //Socket.defaultSocket.on('start:tracking', function(state){
        //	vm.isEmitting = state.isActive;
        //});
        Socket.defaultSocket.on('connect', function(){
        	Socket.defaultSocket.emit('mRoom', {id: '596d2877ef4c960ecc7859ac'});
        });
        // Recibir datos en tiempo real, para activar una notificacion
        Socket.defaultSocket.on('device-signal', function(coords){
        	var alert = JSON.parse(coords);
        	vm.alertRoom.idUser = coords.idUser;
        	vm.alertRoom.idDevice = coords.idDevice;
        	sortAlerts(alert);
        	console.log(vm.alerts);
        	/*
        	vm.alerts.push({
        		idUser: alert.idUser,
        		idDevce: alert.idDevce
        	});
        	*/
        	/*
			if(($("element").data('bs.modal') || {}).isShown){
				return
			}else{
				$('#alertaAuxilio').modal('show');
			}
			*/
			console.log(vm.routeGraph);
			/*
			vm.isFirstEmit.state = coords.isFirstEmit.state;
			if(vm.isFirstEmit.initMarker){
				vm.markers[0].coords = {
					latitude: coords.latitude,
					longitude: coords.longitude
				};
				//vm.isFirstEmit.initMarker = false;
				Socket.defaultSocket.emit('initMarker', {active: false});
				console.log('primer marker');
			}
			vm.markers[1].coords = {
				latitude: coords.latitude,
				longitude: coords.longitude
			};
			*/
        });


		Socket.defaultSocket.on('tracking', function(coords){
			vm.routeGraph.path.push({
				latitude: coords.latitude,
				longitude: coords.longitude
			});
			console.log(vm.routeGraph);
			vm.isFirstEmit.state = coords.isFirstEmit.state;
			if(vm.isFirstEmit.initMarker){
				vm.markers[0].coords = {
					latitude: coords.latitude,
					longitude: coords.longitude
				};
				//vm.isFirstEmit.initMarker = false;
				Socket.defaultSocket.emit('initMarker', {active: false});
				console.log('primer marker');
			}
			vm.markers[1].coords = {
				latitude: coords.latitude,
				longitude: coords.longitude
			};
		});
		Socket.defaultSocket.on('stop:tracking', function(state){
			console.log(state);
			if(!state.isActive){
				$interval.cancel(promise);
				vm.isEmitting = state.isActive;
			}
		});
		Socket.defaultSocket.on('start:tracking', function(state){
			if(state.isActive){
				initInterval();
				vm.isEmitting = state.isActive;				
			}
		});
		Socket.defaultSocket.on('initMarker', function(state){
			console.log(state);
			vm.isFirstEmit.initMarker = state.active;
		});
		Socket.defaultSocket.on('start-track', function(id){
			console.log(id);
		});
		function sortAlerts(data){
			console.log(vm.alerts.length, data);
			if(vm.alerts.length == 0){
				vm.alerts.push(data);
				return;				
			}
			for (var i = 0; i < vm.alerts.length; i++) {
				console.log(vm.alerts[i]);
				if(vm.alerts[i].idDevice == data.idDevice)
					return;
				else
					vm.alerts.push(data);
			}
			console.log(vm.alerts);
		};
		function fireAlert(){
			$('#alertaAuxilio').modal('hide');
			$timeout(function(){
				$state.go('tracking-room', vm.alertRoom);
			}, 500);
		};
		function sign(num){
			if(Math.random() > 0.5){
				return num;
			}else{
				return -num;
			}
		};
		function rand(){
			return sign(Math.random() * 0.005);
		};
		function initInterval(){
			promise = $interval(randomCoords, 2000);
		};
		function cancelInterval(){
			Socket.defaultSocket.emit('stop:tracking', {isActive: false});
		};
		function startInterval(){
			Socket.defaultSocket.emit('start:tracking', {isActive: true});
		};
		function randomCoords(){
			var initCoords = vm.coords;
			var newCoords = {
				latitude: vm.coords.latitude + rand(),
				longitude: vm.coords.longitude + rand(),
				isFirstEmit: {
					initMarker: true,
					state: true
				},

			};
		    Socket.defaultSocket.emit('track', newCoords);
		    vm.coords = newCoords;
		};
	};
})();