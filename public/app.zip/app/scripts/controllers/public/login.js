(function(){
	'use strict';
	angular.module('4trackApp')
		.controller('LoginCtrl', LoginCtrl);
	LoginCtrl.$inyect = ['Auth', '$state'];
	function LoginCtrl(Auth, $state){	
		var vm = this;
		vm.login = {
			userName: '',
			password: '',
			loginSuccess: true,
			msg: ''
		};
		vm.iniciarSesion = iniciarSesion;

		function iniciarSesion(){
			var creds = {
				userName: vm.login.userName,
				password: vm.login.password
			};
			Auth.login(creds).then(function(data){
				if(data.success){
					Auth.setSession(data.user._id, data.user.coords);
					$state.go('estacion');
				}else{
					vm.login.loginSuccess = false;
					vm.login.msg = data.msg;
				}
			}, function(data){
				alert('Hubo un error en el servidor, revise su conexión a internet');
			});
		};
	};
})();