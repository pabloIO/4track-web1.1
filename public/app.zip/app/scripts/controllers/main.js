'use strict';

/**
 * @ngdoc function
 * @name 4trackApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the 4trackApp
 */
angular.module('4trackApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
